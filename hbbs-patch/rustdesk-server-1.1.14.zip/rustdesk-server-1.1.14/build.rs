fn main() {
    hbb_common::gen_version();
}
